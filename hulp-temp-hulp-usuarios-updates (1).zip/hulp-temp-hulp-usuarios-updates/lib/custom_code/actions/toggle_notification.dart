// Automatic FlutterFlow imports
import '/backend/schema/structs/index.dart';
import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:onesignal_flutter/onesignal_flutter.dart';
// Set your action name, define your arguments and return parameter,
// and then add the boilerplate code using the green button on the right!

Future<void> toggleNotification(bool enabled) async {
  try {
    await OneSignal.User.addTags({
      'notifications_enabled': enabled.toString(),
    });
    print('🔁 Tag actualizado: notifications_enabled = ${enabled.toString()}');
  } catch (e) {
    print('❌ Error actualizando el tag: $e');
  }
}
